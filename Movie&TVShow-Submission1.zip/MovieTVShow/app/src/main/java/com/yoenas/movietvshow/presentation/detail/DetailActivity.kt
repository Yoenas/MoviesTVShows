package com.yoenas.movietvshow.presentation.detail

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.yoenas.movietvshow.R
import com.yoenas.movietvshow.data.MovieTvShow
import com.yoenas.movietvshow.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private var _binding: ActivityDetailBinding? = null
    private val binding get() = _binding as ActivityDetailBinding

    private var data: MovieTvShow? = null
    private var viewModel: DetailViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarDetail)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.collapseToolbarDetail.setExpandedTitleColor(Color.TRANSPARENT)

        viewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(DetailViewModel::class.java)

        val id = intent.getStringExtra(EXTRA_DATA)

        viewModel?.apply {
            when {
                id?.startsWith('m', false) == true -> {
                    setMovieId(id)
                    data = getDetailMovieById()
                }

                id?.startsWith('t', false) == true -> {
                    setTvShowId(id)
                    data = getDetailTvShowById()
                }
            }
        }
        showDetailMovieTvShow()
    }

    private fun showDetailMovieTvShow() {
        binding.apply {
            Glide.with(this@DetailActivity).load(data?.poster)
                .placeholder(R.drawable.ic_broken_image).error(R.drawable.ic_broken_image)
                .into(imgDetail)

            Glide.with(this@DetailActivity).load(data?.poster)
                .placeholder(R.drawable.ic_broken_image).error(R.drawable.ic_broken_image)
                .into(imgPosterDetail)

            tvTitleDetail.text = data?.title
            tvRatingDetail.text = data?.rating
            tvReleasedDetail.text = data?.released
            tvGenreDetail.text = data?.genre
            tvDurationDetail.text = data?.duration
            tvDescDetail.text = data?.desc
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    companion object {
        const val EXTRA_DATA = "data"
    }
}